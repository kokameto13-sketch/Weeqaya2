// Server-side cleanup function.
// Deploy with Supabase CLI. Set SERVICE_ROLE_KEY as a secret.
// The Android APK must NEVER contain SERVICE_ROLE_KEY.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(supabaseUrl, serviceRoleKey);

const SAFETY_LIMIT = 850 * 1024 * 1024; // internal safety threshold ~850 MB

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const newProjectBytes = Number(body.newProjectBytes ?? 0);

    if (!Number.isFinite(newProjectBytes) || newProjectBytes < 0) {
      return new Response(JSON.stringify({ error: "invalid newProjectBytes" }), { status: 400 });
    }

    const { data: projects, error } = await supabase
      .from("maintenance_projects")
      .select("id,total_bytes,status,created_at")
      .eq("status", "COMPLETED")
      .order("created_at", { ascending: true });

    if (error) throw error;

    let used = 0;
    for (const p of projects ?? []) used += Number(p.total_bytes ?? 0);

    const deleted: string[] = [];

    while (used + newProjectBytes > SAFETY_LIMIT && (projects ?? []).length) {
      const p = projects.shift()!;
      const { data: photos } = await supabase
        .from("maintenance_photos")
        .select("object_path,byte_size")
        .eq("project_id", p.id);

      for (const photo of photos ?? []) {
        await supabase.storage.from("maintenance-photos").remove([photo.object_path]);
      }

      await supabase.from("maintenance_projects").delete().eq("id", p.id);
      used -= Number(p.total_bytes ?? 0);
      deleted.push(p.id);
    }

    return new Response(JSON.stringify({
      ok: true,
      deletedProjectIds: deleted,
      trackedBytesAfterCleanup: used
    }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
