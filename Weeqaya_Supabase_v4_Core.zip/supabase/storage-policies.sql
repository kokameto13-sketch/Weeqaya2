-- Storage policies for the private maintenance-photos bucket.
-- These policies assume object paths: projects/{project_id}/before/... or after/...

create policy "Weeqaya photos select"
on storage.objects for select
to authenticated
using (
  bucket_id = 'maintenance-photos'
  and public.is_active_user()
);

create policy "Weeqaya photos insert"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'maintenance-photos'
  and public.is_active_user()
  and exists (
    select 1
    from public.maintenance_projects p
    where p.id::text = split_part(name, '/', 2)
      and (p.created_by = auth.uid() or public.is_admin())
      and p.status = 'IN_PROGRESS'
  )
);

create policy "Weeqaya photos delete"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'maintenance-photos'
  and (
    public.is_admin()
    or exists (
      select 1
      from public.maintenance_projects p
      where p.id::text = split_part(name, '/', 2)
        and p.created_by = auth.uid()
        and p.status = 'IN_PROGRESS'
    )
  )
);
