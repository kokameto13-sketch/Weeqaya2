-- Weeqaya: central database schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  full_name text not null default '',
  role text not null check (role in ('ADMIN','ENGINEER')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.maintenance_projects (
  id uuid primary key default gen_random_uuid(),
  month text not null,
  control_name text not null,
  bar text not null,
  distributor_name text not null,
  status text not null default 'IN_PROGRESS'
    check (status in ('IN_PROGRESS','COMPLETED','APPROVED')),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  total_bytes bigint not null default 0,
  before_count integer not null default 0,
  after_count integer not null default 0
);

create table if not exists public.maintenance_photos (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.maintenance_projects(id) on delete cascade,
  side text not null check (side in ('BEFORE','AFTER')),
  object_path text not null unique,
  byte_size bigint not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_projects_created_at
  on public.maintenance_projects(created_at);

create index if not exists idx_projects_search
  on public.maintenance_projects(month, control_name, bar, distributor_name);

create index if not exists idx_photos_project
  on public.maintenance_photos(project_id);

alter table public.profiles enable row level security;
alter table public.maintenance_projects enable row level security;
alter table public.maintenance_photos enable row level security;

create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'ADMIN' and active = true
  );
$$;

create or replace function public.is_active_user()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and active = true
  );
$$;

drop policy if exists profiles_self_or_admin on public.profiles;
create policy profiles_self_or_admin on public.profiles
for select using (id = auth.uid() or public.is_admin());

drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles
for update using (public.is_admin()) with check (public.is_admin());

drop policy if exists projects_select_active on public.maintenance_projects;
create policy projects_select_active on public.maintenance_projects
for select using (public.is_active_user());

drop policy if exists projects_insert_engineer on public.maintenance_projects;
create policy projects_insert_engineer on public.maintenance_projects
for insert with check (
  public.is_active_user()
  and exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('ADMIN','ENGINEER')
  )
  and created_by = auth.uid()
);

drop policy if exists projects_update_owner on public.maintenance_projects;
create policy projects_update_owner on public.maintenance_projects
for update using (
  public.is_admin()
  or (created_by = auth.uid() and status = 'IN_PROGRESS')
) with check (
  public.is_admin()
  or (created_by = auth.uid() and status in ('IN_PROGRESS','COMPLETED'))
);

drop policy if exists projects_delete_admin on public.maintenance_projects;
create policy projects_delete_admin on public.maintenance_projects
for delete using (public.is_admin());

drop policy if exists photos_select_active on public.maintenance_photos;
create policy photos_select_active on public.maintenance_photos
for select using (public.is_active_user());

drop policy if exists photos_insert_owner on public.maintenance_photos;
create policy photos_insert_owner on public.maintenance_photos
for insert with check (
  exists (
    select 1 from public.maintenance_projects p
    where p.id = project_id
      and (p.created_by = auth.uid() or public.is_admin())
      and p.status = 'IN_PROGRESS'
  )
);

drop policy if exists photos_delete_owner on public.maintenance_photos;
create policy photos_delete_owner on public.maintenance_photos
for delete using (
  public.is_admin()
  or exists (
    select 1 from public.maintenance_projects p
    where p.id = project_id
      and p.created_by = auth.uid()
      and p.status = 'IN_PROGRESS'
  )
);

-- Create the storage bucket manually in Supabase Storage:
-- bucket name: maintenance-photos
-- private: true


-- Resolve an internal username to the Auth email used only by the client during sign-in.
-- The app never displays the email to the user.
create or replace function public.resolve_login_email(p_username text)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object('email', u.email)
  from public.profiles p
  join auth.users u on u.id = p.id
  where lower(p.username) = lower(trim(p_username))
    and p.active = true
  limit 1;
$$;

grant execute on function public.resolve_login_email(text) to anon, authenticated;

-- Data API grants required by the Android client. RLS remains the security boundary.
grant select on public.profiles to authenticated;
grant select, insert, update, delete on public.maintenance_projects to authenticated;
grant select, insert, delete on public.maintenance_photos to authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_active_user() to authenticated;
grant execute on function public.resolve_login_email(text) to anon, authenticated;
