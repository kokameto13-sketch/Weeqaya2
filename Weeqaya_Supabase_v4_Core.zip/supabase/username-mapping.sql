-- أسماء الدخول المعتمدة للحسابين الحاليين
update public.profiles
set username = 'admin'
where id = '258ad4aa-80b1-4acd-bd5d-2f86ff7c1e2b';

update public.profiles
set username = 'engineer1'
where id = '5843d924-8576-42ac-894d-fcb95c23325c';
