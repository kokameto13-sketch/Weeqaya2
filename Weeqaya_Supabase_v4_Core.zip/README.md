# Weeqaya - Supabase Android Project

نسخة التنفيذ الأولى المعتمدة:
- صلاحيتان فقط: مدير البرنامج (ADMIN) ومهندس الصيانة (ENGINEER).
- تخزين مركزي باستخدام Supabase.
- صور قبل/بعد الصيانة.
- ضغط تلقائي يحافظ على جودة الصورة.
- لا يوجد حد ثابت لحجم الصورة من جهة المستخدم.
- إدارة المساحة بحذف أقدم مشروع مكتمل عند الحاجة.
- مفتاح service_role لا يوضع داخل تطبيق Android.

## قبل البناء
1. أنشئ مشروع Supabase.
2. نفذ `supabase/schema.sql` من SQL Editor.
3. أنشئ Edge Function من `supabase/functions/ensure-space`.
4. ضع URL وanon key في `local.properties`:
   SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   SUPABASE_ANON_KEY=YOUR_ANON_KEY

لا تضع service_role key داخل APK.

## ملاحظة
هذه نسخة أساس تنفيذية منظمة للمشروع. شاشة الكاميرا والواجهات الأساسية موجودة كهيكل قابل للتوسعة، بينما منطق التخزين والصلاحيات وقاعدة البيانات محدد في ملفات Supabase.

## نظام الدخول المعتمد
واجهة البرنامج لا تعرض البريد الإلكتروني للمستخدم.
- مدير البرنامج يدخل باسم مستخدم وكلمة مرور.
- مهندس الصيانة يدخل باسم مستخدم وكلمة مرور.
- البريد الإلكتروني في Supabase يستخدم داخليًا فقط كوسيلة Auth.
- مدير البرنامج هو الذي ينشئ حسابات المهندسين.

## Supabase connection
The Android client is configured for the Weeqaya Supabase project using the Project URL and the publishable client key. The secret/service key is not used in the APK.

## Login
The app accepts username + password. It resolves the internal username to the existing Supabase Auth account, signs in, then reads the authenticated profile to determine ADMIN or ENGINEER.

## المرحلة الحالية
- تسجيل الدخول باسم مستخدم وكلمة مرور مع Supabase Auth داخليًا.
- صلاحيتان فقط: ADMIN و ENGINEER.
- مهندس الصيانة يستطيع إنشاء عملية، التقاط عدد غير محدود من صور قبل/بعد، ضغط الصور تلقائيًا، ورفعها إلى bucket الخاص.
- لا يوجد حد صوري ثابت على عدد الصور؛ الجودة هي الأولوية.
- زر "حفظ الصور" يرفع الصور ويُبقي العملية IN_PROGRESS، وزر "إنهاء العملية" يحولها إلى COMPLETED بعد وجود صور قبل وبعد.
- ملف `supabase/storage-policies.sql` يجب تشغيله إذا لم تكن سياسات Storage الحالية تغطي هذه المسارات.
