package com.weeqaya.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

private val supabase = createSupabaseClient(
    supabaseUrl = BuildConfig.SUPABASE_URL,
    supabaseKey = BuildConfig.SUPABASE_PUBLISHABLE_KEY
) {
    install(io.github.jan.supabase.auth.Auth)
    install(io.github.jan.supabase.postgrest.Postgrest)
    install(io.github.jan.supabase.storage.Storage)
}

enum class UserRole { ADMIN, ENGINEER }

enum class PhotoSide { BEFORE, AFTER }

@Serializable
data class LoginLookup(val email: String)

@Serializable
data class Profile(
    val id: String,
    val username: String,
    val full_name: String,
    val role: String,
    val active: Boolean
)

@Serializable
data class ProjectInsert(
    val id: String,
    val month: String,
    val control_name: String,
    val bar: String,
    val distributor_name: String,
    val status: String = "IN_PROGRESS",
    val created_by: String,
    val total_bytes: Long = 0,
    val before_count: Int = 0,
    val after_count: Int = 0
)

@Serializable
data class PhotoInsert(
    val project_id: String,
    val side: String,
    val object_path: String,
    val byte_size: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { WeeqayaApp() } }
    }
}

@Composable
fun WeeqayaApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var role by remember { mutableStateOf(UserRole.ENGINEER) }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (!loggedIn) {
        LoginScreen(
            busy = busy,
            error = error,
            onLogin = { username, password ->
                error = ""
                busy = true
                scope.launch {
                    try {
                        val lookup = supabase.postgrest.rpc(
                            "resolve_login_email",
                            buildJsonObject { put("p_username", JsonPrimitive(username.trim())) }
                        ).decodeSingle<LoginLookup>()

                        supabase.auth.signInWith(Email) {
                            email = lookup.email
                            this.password = password
                        }

                        val uid = supabase.auth.currentUserOrNull()?.id
                            ?: throw IllegalStateException("تعذر إنشاء جلسة الدخول")

                        val profile = supabase.postgrest.from("profiles").select {
                            filter { eq("id", uid) }
                        }.decodeSingle<Profile>()

                        if (!profile.active) throw IllegalStateException("الحساب غير مفعل")
                        role = when (profile.role) {
                            "ADMIN" -> UserRole.ADMIN
                            "ENGINEER" -> UserRole.ENGINEER
                            else -> throw IllegalStateException("صلاحية غير معروفة")
                        }
                        loggedIn = true
                    } catch (_: Exception) {
                        error = "اسم المستخدم أو كلمة المرور غير صحيحة"
                        runCatching { supabase.auth.signOut() }
                    } finally {
                        busy = false
                    }
                }
            }
        )
    } else {
        DashboardScreen(
            role = role,
            onLogout = {
                scope.launch {
                    runCatching { supabase.auth.signOut() }
                    loggedIn = false
                }
            }
        )
    }
}

@Composable
fun LoginScreen(busy: Boolean, error: String, onLogin: (String, String) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Weeqaya", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text("نظام توثيق أعمال الصيانة")
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم") }, singleLine = true, enabled = !busy)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            password,
            { password = it },
            label = { Text("كلمة المرور") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            enabled = !busy
        )
        Spacer(Modifier.height(20.dp))
        Button(enabled = !busy && username.isNotBlank() && password.isNotBlank(), onClick = { onLogin(username, password) }) {
            Text(if (busy) "جارٍ تسجيل الدخول..." else "تسجيل الدخول")
        }
        if (error.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
fun DashboardScreen(role: UserRole, onLogout: () -> Unit) {
    var showCreate by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(if (role == UserRole.ADMIN) "مدير البرنامج" else "مهندس الصيانة", style = MaterialTheme.typography.headlineMedium)
            TextButton(onClick = onLogout) { Text("خروج") }
        }
        Spacer(Modifier.height(20.dp))
        if (role == UserRole.ENGINEER) {
            Button(onClick = { showCreate = true }) { Text("عملية صيانة جديدة") }
            Spacer(Modifier.height(12.dp))
            Text("البحث ومشاهدة عمليات الصيانة سيُضاف في المرحلة التالية")
        } else {
            Text("لوحة مدير البرنامج")
            Spacer(Modifier.height(12.dp))
            Text("إدارة المستخدمين والتخزين ومراجعة العمليات ستُضاف في المرحلة التالية")
        }
        if (showCreate) {
            Spacer(Modifier.height(20.dp))
            MaintenanceForm(onClose = { showCreate = false })
        }
    }
}

@Composable
fun MaintenanceForm(onClose: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var month by remember { mutableStateOf("") }
    var control by remember { mutableStateOf("") }
    var bar by remember { mutableStateOf("") }
    var distributor by remember { mutableStateOf("") }
    var projectId by remember { mutableStateOf<String?>(null) }
    var beforePhotos by remember { mutableStateOf(listOf<ByteArray>()) }
    var afterPhotos by remember { mutableStateOf(listOf<ByteArray>()) }
    var uploadedBeforeCount by remember { mutableStateOf(0) }
    var uploadedAfterCount by remember { mutableStateOf(0) }
    var uploadedBytes by remember { mutableStateOf(0L) }
    var pendingSide by remember { mutableStateOf(PhotoSide.BEFORE) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun newCaptureUri(): Uri {
        val file = File.createTempFile("weeqaya_", ".jpg", context.cacheDir)
        return FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingUri
        if (ok && uri != null) {
            scope.launch {
                try {
                    val bytes = compressImage(context, uri)
                    if (pendingSide == PhotoSide.BEFORE) beforePhotos = beforePhotos + bytes
                    else afterPhotos = afterPhotos + bytes
                    message = "تمت إضافة الصورة (${bytes.size / 1024} KB)"
                    error = ""
                } catch (e: Exception) {
                    error = "تعذر تجهيز الصورة: ${e.message ?: "خطأ غير معروف"}"
                }
            }
        }
        pendingUri = null
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) cameraLauncher.launch(pendingUri ?: newCaptureUri())
        else error = "يجب السماح للكاميرا لتصوير أعمال الصيانة"
    }

    fun capture(side: PhotoSide) {
        pendingSide = side
        val uri = newCaptureUri()
        pendingUri = uri
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            cameraLauncher.launch(uri)
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    suspend fun createProject(): String {
        val uid = supabase.auth.currentUserOrNull()?.id ?: error("انتهت جلسة الدخول")
        val id = UUID.randomUUID().toString()
        supabase.postgrest.from("maintenance_projects").insert(
            ProjectInsert(
                id = id,
                month = month.trim(),
                control_name = control.trim(),
                bar = bar.trim(),
                distributor_name = distributor.trim(),
                created_by = uid
            )
        )
        return id
    }

    suspend fun uploadSide(id: String, side: PhotoSide, photos: List<ByteArray>): Long {
        val bucket = supabase.storage.from("maintenance-photos")
        var total = 0L
        photos.forEachIndexed { index, bytes ->
            val sideName = if (side == PhotoSide.BEFORE) "before" else "after"
            val path = "projects/$id/$sideName/${index + 1}_${UUID.randomUUID()}.jpg"
            bucket.upload(path, bytes) { upsert = false }
            supabase.postgrest.from("maintenance_photos").insert(
                PhotoInsert(
                    project_id = id,
                    side = side.name,
                    object_path = path,
                    byte_size = bytes.size.toLong()
                )
            )
            total += bytes.size
            if (side == PhotoSide.BEFORE) uploadedBeforeCount++ else uploadedAfterCount++
            uploadedBytes += bytes.size
        }
        return total
    }

    suspend fun saveProject(finalize: Boolean) {
        if (month.isBlank() || control.isBlank() || bar.isBlank() || distributor.isBlank()) {
            throw IllegalArgumentException("أكمل بيانات عملية الصيانة أولًا")
        }
        if (beforePhotos.isEmpty() && afterPhotos.isEmpty()) {
            throw IllegalArgumentException("أضف صورة واحدة على الأقل")
        }
        if (finalize && (uploadedBeforeCount + beforePhotos.size == 0 || uploadedAfterCount + afterPhotos.size == 0)) {
            throw IllegalArgumentException("لإنهاء العملية يجب وجود صور قبل وبعد الصيانة")
        }

        val id = projectId ?: createProject().also { projectId = it }
        uploadSide(id, PhotoSide.BEFORE, beforePhotos)
        uploadSide(id, PhotoSide.AFTER, afterPhotos)

        supabase.postgrest.from("maintenance_projects").update(
            buildJsonObject {
                put("total_bytes", uploadedBytes)
                put("before_count", uploadedBeforeCount)
                put("after_count", uploadedAfterCount)
                if (finalize) {
                    put("status", "COMPLETED")
                    put("completed_at", java.time.OffsetDateTime.now().toString())
                }
            }
        ) {
            filter { eq("id", id) }
        }
        beforePhotos = emptyList()
        afterPhotos = emptyList()
        message = if (finalize) "تم حفظ وإكمال عملية الصيانة" else "تم رفع الصور وحفظ العملية كعملية غير مكتملة"
    }

    LazyColumn(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("عملية صيانة جديدة", style = MaterialTheme.typography.headlineSmall) }
        item { OutlinedTextField(month, { month = it }, label = { Text("شهر الصيانة") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(control, { control = it }, label = { Text("اسم التحكم") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(bar, { bar = it }, label = { Text("البار") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(distributor, { distributor = it }, label = { Text("اسم الموزع") }, modifier = Modifier.fillMaxWidth()) }
        item { Text("قبل الصيانة: ${uploadedBeforeCount + beforePhotos.size} صورة") }
        item { Button(enabled = !busy, onClick = { capture(PhotoSide.BEFORE) }) { Text("تصوير قبل الصيانة") } }
        item { Text("بعد الصيانة: ${uploadedAfterCount + afterPhotos.size} صورة") }
        item { Button(enabled = !busy, onClick = { capture(PhotoSide.AFTER) }) { Text("تصوير بعد الصيانة") } }
        item { Text("لا يوجد حد لعدد الصور. يتم ضغطها تلقائيًا مع الحفاظ على الجودة.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = {
                    busy = true; error = ""; scope.launch {
                        try { saveProject(false) } catch (e: Exception) { error = e.message ?: "تعذر الحفظ" } finally { busy = false }
                    }
                }) { Text("حفظ الصور") }
                Button(enabled = !busy, onClick = {
                    busy = true; error = ""; scope.launch {
                        try { saveProject(true) } catch (e: Exception) { error = e.message ?: "تعذر إنهاء العملية" } finally { busy = false }
                    }
                }) { Text("إنهاء العملية") }
            }
        }
        item { Text(if (busy) "جارٍ الرفع..." else message) }
        if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
        item { TextButton(enabled = !busy, onClick = onClose) { Text("إغلاق") } }
    }
}

private fun compressImage(context: android.content.Context, uri: Uri): ByteArray {
    val resolver = context.contentResolver
    val original = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        ?: error("تعذر قراءة الصورة")

    val exif = resolver.openInputStream(uri)?.use { ExifInterface(it) }
    val orientation = exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        ?: ExifInterface.ORIENTATION_NORMAL

    val rotated = when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> rotate(original, 90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> rotate(original, 180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> rotate(original, 270f)
        else -> original
    }

    val maxSide = 2048
    val scale = minOf(1f, maxSide.toFloat() / maxOf(rotated.width, rotated.height).toFloat())
    val scaled = if (scale < 1f) {
        Bitmap.createScaledBitmap(rotated, (rotated.width * scale).toInt(), (rotated.height * scale).toInt(), true)
    } else rotated

    val out = ByteArrayOutputStream()
    scaled.compress(Bitmap.CompressFormat.JPEG, 86, out)
    if (scaled !== rotated) scaled.recycle()
    if (rotated !== original) rotated.recycle()
    original.recycle()
    return out.toByteArray()
}

private fun rotate(bitmap: Bitmap, degrees: Float): Bitmap {
    val matrix = Matrix().apply { postRotate(degrees) }
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
}
